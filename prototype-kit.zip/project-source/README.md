# Travel Globe — Places, remembered.

A visual prototype for a **305 mm (12-inch) programmable travel globe**: charcoal raised terrain, warm gold **visited areas**, and dark places still to explore.

Each saved place contributes an approximate footprint, initially **50 miles in radius**. Nearby footprints merge. No connecting travel lines are drawn, and visiting a city never selects its entire country. The opening example highlights Vancouver while leaving distant Canada and South Dakota dark.

## Physical build\n\nRead the [online build guide](https://trentconley.github.io/globe/build-guide.html) for the 25× terrain / 50-mile design, verified prototype electronics, optical tests, shell construction, power and storage architecture, and release gates. The package includes small material/terrain sample STLs and a bench utility; a full custom PCB and device firmware are not yet released.\n\n## Open and use

Open [the public simulator](https://trentconley.github.io/globe/) in a modern browser, or use `dist/globe.html` locally. The renderer, coastline, and elevation data are bundled into this self-contained file. Some phone file viewers block HTML; the local-server option below is an alternative.

- Add a place by latitude/longitude, or pick its coordinates with **Add on globe**.
- Adjust **Approximate visit radius** to balance recognition and physical display resolution.
- Try **Overlapping Bay Area visits** to see nearby footprints merge, or **Scattered western visits** to see gaps remain dark. These are illustrative examples, not claims about your travel history.
- **Keep highlights on land** clips the visual footprints to the simplified coastline. Turn it off to see the full footprint. This does not promise that the hardware can resolve every coastal edge.
- Use **Print section** to inspect a curved section of the full-size globe and export a shell STL in millimetres. The geography is fixed; changing your visited places changes the light, not the print.
- Compare the ideal coverage with **Show coarse 72-LED approximation** before buying hardware. The cheap test layout can enlarge, shift, or merge small areas.
- Export travel JSON as a backup. Browser storage retains visits locally; it is not the future controller's nonvolatile storage.

On a 305 mm globe, a 50-mile radius is **1.93 mm**, making one footprint about **3.85 mm across**. Zoom in to inspect small areas; the simulator does not artificially enlarge them in the ideal view.

## Build and run

With Node 20+:

```sh
cd /workspace/globe
npm ci
npm run build
npm test
```

Optional local server: `npm start` serves `dist` on port 4173. A phone on the same local network can use the computer's LAN address and port. This development server has no authentication; stop it when finished.

## Saved history

New exports use `{ "version": 2, "radiusMiles": 50, "visits": [{ "name": "Vancouver", "lat": 49.2827, "lon": -123.1207 }] }`.

The simulator accepts earlier version 1 travel files and retains their place coordinates, ignoring old connection flags. Existing personal browser history is migrated to a new storage key, while the original version 1 entry is preserved. The earlier illustrative route demo is replaced by the Vancouver example.

## What the preview and print represent

- Real simplified coastlines and **ETOPO-derived elevation**, showing major ranges with adjustable vertical exaggeration. The preview and STL use the same elevation field.
- Nominal diameter 305 mm before relief. Default 25× exaggeration raises the highest sampled terrain about 3.73 mm; the 40× setting reaches about 5.96 mm. Individual peaks are averaged by the coarse grid.
- Exported curved section: 36° × 36°, about 95 mm across, with at least a 1 mm radial base wall.
- Terrain stays fixed. There are no visit-specific grooves or engraved paths in the print.
- STL contains shape only, without color, lighting, tint, support structures, or printer settings. The display stand is a visual concept, not an exported engineering design.

See [terrain data and scale](docs/elevation.md), [the physical prototype guide](docs/prototype.md), [design decisions](docs/design.md), and [validation record](docs/validation.md). The physical finish, lighting, electronics, and phone-to-controller updates remain to be tested and built.

Coastlines are public-domain [Natural Earth land data](https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_110m_land.geojson); see [provenance](docs/sources.md). Rendering uses Three.js (MIT).


To reproduce the engineering artifacts, run node tools/build-engineering.mjs. Render the web guide with python3 tools/build-guide.py after installing the pinned dependency in tools/requirements-docs.txt. The prototype BOM and test-log CSVs in engineering/ are source inputs copied into the distribution; tools/package-kit.py assembles the tested simulator, guide and outputs.
