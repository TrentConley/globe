import {build} from 'esbuild';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
const result=await build({entryPoints:['preview/app.js'],bundle:true,minify:true,format:'iife',write:false,loader:{'.geojson':'json'},legalComments:'inline',target:['es2020']});
const [template,css,license,elevationLicense]=await Promise.all([readFile('preview/index.html','utf8'),readFile('preview/style.css','utf8'),readFile('node_modules/three/LICENSE','utf8'),readFile('docs/elevation-data-license.md','utf8')]);
const script=result.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
// A callback inserts the bundle literally; minified JS can contain replacement tokens such as $&.
const html=template.replace('<!-- APP_STYLE -->',()=>`<!-- Three.js license:\n${license}\nElevation data distribution license:\n${elevationLicense}\n--><style>${css}</style>`).replace('<!-- APP_SCRIPT -->',()=>`<script>${script}</script>`);
await mkdir('dist',{recursive:true});await writeFile('dist/globe.html',html);await writeFile('dist/index.html',html);
console.log(`Built a self-contained simulator: dist/globe.html (${Math.round(Buffer.byteLength(html)/1024)} KiB). No network or server required to open it.`);
