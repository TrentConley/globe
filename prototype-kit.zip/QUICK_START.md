# Travel Globe — visited areas

Open globe.html in a modern browser. All rendering code, land outlines, and elevation data are included. If your file viewer blocks local HTML, serve this folder with `python3 -m http.server 4173` and open it through your browser.

Start with Vancouver only. Each place adds a roughly 50-mile-radius footprint; nearby footprints merge. Distant places remain dark and no connecting lines are drawn. Other examples are illustrations, not your personal history.

Use Print section to inspect the full-size curvature. The supplied examples use Vancouver at 49.2827 N, 123.1207 W on a nominal 305 mm globe:

- examples/example-light-only-shell-mm.stl: a reusable, 1 mm minimum wall shell.
- examples/example-led-carrier-mm.stl: a blank curved backing, not a complete mount.
- examples/example-travels.json: Vancouver with a 50-mile footprint radius.

STL units are millimetres. The shell is about 95 mm wide. The carrier is smaller because it follows an inner concentric sphere; do not enlarge it to match the shell's width. The print does not change when visits are added; light changes instead.

Read docs/prototype.md before requesting a print quote. Use translucent shell material for a lighting test. Terrain uses a real, coarse ETOPO-derived elevation grid with 12× vertical exaggeration in the supplied shell; individual peaks are simplified. Geometry and software have been checked; physical printing, optics, wiring, and device firmware remain to be validated.

Export your travel JSON to keep a backup. Browser storage is local and does not configure a physical globe.
