# Travel Globe — physical build design

Open build-guide.html for the complete design, prototype wiring, material tests, fabrication request, costs and acceptance criteria. Open index.html (or globe.html) for the simulator. The design target is 25× terrain and a 50-mile visited-area radius.

Start with the small engineering/ print samples and the identified dense matrix. Read the guide before purchasing or requesting a print. The older coarse strip carrier under examples/ is retained only as a legacy geometry study; it is not the dense-matrix mounting design.

engineering/ contains flat thickness coupons, smooth/Vancouver/Himalayan curved shells, a prototype BOM, optical test log, geographic test pattern and reproducible scale calculations. STL units are millimetres. Samples require print-service material/support review.

firmware/optical-bench/ contains an untested low-current CircuitPython pattern utility and setup instructions. It does not implement the finished globe's Wi-Fi/persistence firmware.

project-source/ preserves the simulator, generators, tests, guide source and pinned dependencies for future maintenance.

The full approximately 95 mm example shell uses Vancouver at 25× with a 1 mm radial base wall. Adding visited places changes light, not the printed geography. Export your travel JSON to keep a backup.

Geometry and browser software have been checked. Physical printing, finish, optics, custom circuits, firmware, wiring and thermal behavior still require the staged validation in the guide. This package is not a released full-globe manufacturing design.
