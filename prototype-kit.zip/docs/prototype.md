# First curved prototype

Designed for a **3D-print service plus basic soldering**, with no commitment to the final LED architecture. The simulator is the first approval step; these notes describe the next physical experiment, not a completed hardware build.

## Print-service request

From the simulator, select **Print section**, center the section on the desired visited region, and export:

1. **Light-only shell**, preferably natural/translucent PETG or a suitable translucent service material. Base radius 152.5 mm; radial base thickness 1 mm; real elevation relief, exaggerated 4× by default (up to about 0.60 mm above the base shell globally). Approximate face dimensions 95 × 95 mm. The material, support method, cure/finish, and minimum reliable wall must be agreed with the service. Do not order the transmitting shell in opaque black.
2. **LED carrier**, ordinary opaque material acceptable: outer radius 144.6 mm; wall 1.6 mm; same 36° angular bounds. This is a blank backing surface, not a complete mounting assembly. It has no integrated wire channels, holes, strip indexing features, or fasteners.
STL units are not encoded by the format. Tell the service **millimetres** and confirm the shell is about 95 mm wide in their slicer. Do not use automatic fitting or scaling to a different size. The curved part is not flat on a print bed; these exports require supports/orientation review, not direct printing with assumed settings. Keep support scars off the display face when possible. Do not use this prototype as a structural enclosure.

The exported shell has fixed real elevation relief masked to simplified coastlines. It does not include internal light baffles, tint, or a painted ocean mask. The elevation grid represents major mountain ranges; it averages away individual peaks. The STL is a closed volume, but printable supports and optical performance have not been established by software checks.

## Candidate lighting layout

- Buy one metre of **5 V, individually addressable RGB strip, 144 LEDs/m**, with a PCB width **no more than 12 mm**, cuttable at each LED. Confirm the actual vendor's voltage, pitch, width, cut interval, LED height, and signaling. This is a specification, not a verified part number.
- Use **six separate 12-LED lengths**, 72 LEDs total. Each active piece is approximately 83.3 mm long at 6.944 mm pitch; allow actual cut-pad and connector space. Do not substitute a grouped/COB strip without checking its independently controllable segment length.
- Run strips north/south along six local meridians. At the assumed emitter radius 146.5 mm, place their centerlines at local longitudes proportional to **−35, −21, −7, +7, +21, +35 mm** of equatorial arc. LED centers along each strip are at **(row − 5.5) × 6.944 mm**, rows 0–11. Leave solder joints and jumpers free of the visible area.
- Centerlines are about 14 mm apart. Their separation decreases slightly toward the ends. A 12 mm maximum PCB width leaves clearance in this small section; measure the actual assembly.
- The strip itself follows one curved meridian. Do not stretch its width or sharply crease between solder pads; use small supports/adhesive spots and flexible wire bridges between strips.
- Place the outer carrier surface **6.9 mm radially behind the inner shell surface**. The design assumes approximately 1.9 mm total adhesive/PCB-to-emitter height, leaving about **5 mm from emitter to shell**. Measure the selected strip. Adjust temporary spacers to preserve the gap rather than assuming every LED package has this height.
- Use removable edge tape/clips and individually fitted temporary spacers for the test. The exported parts are concentric when aligned by their angular edges, not by simply aligning their trimmed bounding boxes. Keep the LED carrier removable.

The software approximation gives lit sources a roughly 5 mm surface spread. That is a placeholder for comparing density, not a computed consequence of a 5 mm optical gap. Reflective interior surfaces, wall thickness, tint, resin/filament, and baffles can change it substantially.

## Starter shopping list

Approximate planning allowances in USD; not vendor quotes or live prices. Prefer borrowing the controller, supply, and test leads.

| Item | Prototype quantity | Planning allowance |
| --- | ---: | ---: |
| Translucent shell and opaque curved carrier from print service | 1 each | $35–90 |
| 5 V 144/m individually addressable RGB strip meeting dimensions above | 1 m | $20–45 |
| ESP32 development board | 1 | $8–20 |
| Regulated, enclosed 5 V supply with suitable connector | 1 | $12–25 |
| 74AHCT125 or suitable 3.3→5 V data level shifter/breakout | 1 | $3–10 |
| Wire, connectors, series resistor, capacitor, inline fuse holder and suitable fuse | Small set | $12–25 |
| Translucent smoke tint, clear matte finish, diffuser scraps, temporary spacers | Small set | $10–25 |

Allow roughly **$100–240**, excluding tools/shipping and any additional print iterations. Get the print quote before committing. An opaque unlit form-only sample can precede the electronics purchase if the goal is initially just shape and feel.

## Bench wiring and power

Use the LED/controller manufacturers' wiring guidance. A typical 5 V addressable strip prototype uses a shared ground, a 3.3-to-5 V AHCT-family data buffer powered from 5 V, a 330–470 Ω series resistor near the first LED's data input, and a 470–1,000 µF capacitor rated at least 10 V across the strip's supply with correct polarity. Follow data arrows and inspect solder joints before power-up. Route LED current directly through appropriately rated supply wiring, not through the development board or USB port.

Some RGB pixels can draw about 60 mA at full white. At 72 pixels that is **4.32 A / 21.6 W**, although modern parts vary and dim amber can be far lower. Design the supply/wiring for the selected strip's specified maximum, or use a hardware current-limited bench supply and an enforced lower output limit for the test. Start dim. A software brightness limit alone does not replace current-rated wiring and appropriate fusing. Do not assume a 1 A adapter is safe because the intended picture is sparse. Avoid back-powering a controller connected to USB; follow that board's documented power arrangement.

The firmware for controlling this bench layout has not been written or flashed. Before the travel display, its first patterns should be: all off, single-pixel address sweep, alternating rows/columns, dim amber, then one visited footprint and a cluster of visits. These establish wiring order and coordinate mapping. Current and temperature should be measured with the final material stack in place.

## Finish experiment

On small translucent offcuts or one sacrificial edge of the shell, compare:

- Untinted shell, to establish the available light transmission.
- One light translucent charcoal/smoke coat, with a clear matte finish if compatible.
- A second light coat or different diffusion thickness, applied to a separate labeled area.

Check material/finish compatibility on scrap. A thick opaque black coating defeats internal illumination. A dark ocean mask can improve contrast but will also hide offshore parts of a footprint; choose that consciously. Do not use a single geographic visit as a reason to light or paint an entire country.

Photograph each sample unlit and lit from the intended display distance, with the same camera exposure. Warm RGB color depends on the LEDs and tint; tune by eye against the desired amber appearance rather than treating a hexadecimal screen color as a physical specification.

## What the experiment must answer

Start with Vancouver alone: the nearby area should glow while distant Canada and South Dakota stay dark. Then try several familiar visited places, individually and together. The Bay Area example demonstrates overlapping footprints; the scattered western example demonstrates unvisited gaps. At this scale San Francisco–Los Angeles is about 13.4 mm center to center, which is a useful resolution test.

- At roughly 1 m viewing distance, can you recognize the intended region from the lit areas and coastline?
- Does an isolated visit leave visibly unvisited areas within a large country?
- Does the light read as an attractive visited region, rather than an unrelated dotted grid?
- Are merged nearby visits acceptable, and are unrelated distant regions still dark?
- Does the surface look dark when off, warm when on, and pleasant in normal room light?
- Does raising the texture make peaks too opaque or create distracting bright valleys?
- Can you keep enough contrast at a modest, measured brightness without excessive warming?

At a 50-mile radius the ideal footprint is only 3.85 mm across, so the coarse layout may be too large or may shift it. If that approximation is unsatisfying in software, do not scale it to a full globe. If the physical finish fails, change transmission, coating, gap, or diffusion one variable at a time. Smaller, distinct visited areas might need denser hardware even if the sample's finish succeeds.

The later controller milestone must separately verify phone/computer updates and retention after power is physically removed. Browser local storage is not evidence that the eventual device passes that requirement.
