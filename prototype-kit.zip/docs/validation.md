# Validation record — 2026-10-03

## Executed for the visited-area revision

- `npm run build`: generated a self-contained simulator with embedded land data and the renderer license.
- `npm test`: **12 tests passed**, none skipped. They cover scale, spherical footprints, Vancouver versus distant Canada and South Dakota, unvisited gaps, overlap without added brightness, order independence, date-line/pole behavior, soft edges, old-history migration, valid/invalid imports, closed printable geometry, and minimum wall thickness.
- `node tools/browser-smoke.cjs`: **33 checks passed** in Chromium. The rendered Vancouver example lights Vancouver while Montreal, Edmonton, and South Dakota remain unlit. Tests also exercise land clipping, merged Bay Area visits, separated western visits, globe picking, saved history and radius after reload, older JSON imports, browser-history migration without deleting the original entry, the 390 px phone layout, and exports. No runtime errors or external service requests were observed.
- The actual downloaded shell was byte-for-byte identical after adding a distant visit and after increasing footprint radius. Visited history changes lighting, not printable geography.
- Both current example STLs were independently parsed. Every geometric edge belongs to exactly two faces with opposite direction. Both volumes are positive; each file contains 84,096 triangles.

## Current example export measurements

The example shell uses the Vancouver section centered at **49.2827° N, 123.1207° W**, 0.7 mm maximum stylized relief, and a nominal 305 mm globe. The example travel JSON stores Vancouver with a 50-mile radius. Measurements below are bounding-box extents, not surface arc lengths.

| Download | Width × height × depth, mm | Closed volume, mm³ |
| --- | --- | ---: |
| Light-only shell | 94.407 × 94.612 × 16.024 | 10,907.245 |
| LED carrier | 89.368 × 89.368 × 15.255 | 12,847.867 |

The carrier has smaller physical bounds because it follows an inner concentric sphere with the same angular span. Do not scale it to match the shell's bounding box. The current kit includes these two prints; it does not include the superseded engraved-route example.

## Repeating the browser checks

The cloud runtime supplied Playwright 1.62.1 and Chromium. The optional test script requires Playwright to be resolvable by Node and a compatible Chromium binary. If using another machine, install Playwright in your development environment and set `GLOBE_CHROMIUM` to its browser executable if it differs from `/usr/bin/chromium`.

Serve the generated `dist` directory, then run:

```sh
node tools/browser-smoke.cjs
```

It defaults to `http://127.0.0.1:4173/globe.html`; override `GLOBE_TEST_URL` when needed. Screenshots and downloaded test files go under `artifacts/` and contain demonstration data only.

The managed Chromium installation blocks `file://` navigation, so browser automation used a local HTTP server. The standalone file is bundled to open directly in ordinary browsers, but direct file opening was not validated in this managed browser. Phone file viewers may need the local-server option described in the README.

## Not yet established

No physical part has been printed, no LED hardware has been assembled or flashed, and no finish has been tested. Mesh closure and radial wall calculations do not certify a printer, support orientation, minimum wall for a specific material, mechanical strength, heat behavior, or optical transmission. The coarse LED display is illustrative, not measured diffusion. The device's power-loss retention and phone-to-controller updates await the electronics prototype.
