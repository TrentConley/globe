# Public simulator

- Simulator: https://trentconley.github.io/globe/
- Prototype kit: https://trentconley.github.io/globe/prototype-kit.zip
- Published files: https://github.com/TrentConley/globe/tree/gh-pages
- Initial successful deployment: https://github.com/TrentConley/globe/actions/runs/37145966955
- Published commit: dea5dc6 (gh-pages)

GitHub Pages automatically published the initial gh-pages branch. The successful deployment and site URL were confirmed from GitHub's workflow run. The public raw index.html was fetched and matched dist/index.html byte for byte. Direct access to the github.io domain was blocked by this workspace's network policy, so a post-deployment browser smoke test against the live domain was not completed here.

The static public site contains the standalone simulator and example prototype kit only. Travel edits remain in each visitor's browser; there is no server-side history synchronization or hardware connection. Browser storage on the public site's origin is separate from any earlier local-file or development-server history; JSON export/import can transfer visits.

## Updating the public site

Rebuild the simulator and regenerate the kit after the relevant tests. Fetch the current gh-pages branch from the repository before updating it. Replace index.html with dist/index.html and prototype-kit.zip with artifacts/globe-prototype-kit.zip. Retain .nojekyll, commit, and push normally without force. Check the Pages deployment result before announcing an update. The gh-pages branch contains built distribution files; source development remains in the workspace checkout.
