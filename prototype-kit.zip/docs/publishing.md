# Public simulator

- Simulator: https://trentconley.github.io/globe/
- Prototype kit: https://trentconley.github.io/globe/prototype-kit.zip
- Published files: https://github.com/TrentConley/globe/tree/gh-pages
- Initial successful deployment: https://github.com/TrentConley/globe/actions/runs/37145966955
- Initial published commit: dea5dc6 (gh-pages)
- Real-elevation update: cee0d24 (gh-pages)
- Terrain update deployment: https://github.com/TrentConley/globe/actions/runs/37147437199 (completed successfully)

GitHub Pages automatically published the initial gh-pages branch. The successful deployment and site URL were confirmed from GitHub's workflow run. The public raw index.html was fetched and matched dist/index.html byte for byte. Direct access to the github.io domain was blocked by this workspace's network policy, so a post-deployment browser smoke test against the live domain was not completed here.

The static public site contains the standalone simulator and example prototype kit only. Travel edits remain in each visitor's browser; there is no server-side history synchronization or hardware connection. Browser storage on the public site's origin is separate from any earlier local-file or development-server history; JSON export/import can transfer visits.

## Updating the public site

Rebuild the simulator and regenerate the kit after the relevant tests. Fetch the current gh-pages branch from the repository before updating it. Replace index.html with dist/index.html and prototype-kit.zip with artifacts/globe-prototype-kit.zip. Retain .nojekyll, commit, and push normally without force. Check the Pages deployment result before announcing an update. The gh-pages branch contains built distribution files; source development remains in the workspace checkout.

The real-elevation update passed 16 geometry/data tests and 38 browser checks locally. The public raw index at cee0d24 exactly matched the validated build (SHA-256 `59011df15b8e6a07f3fb5fec0dad177c4ce3eacf006dbd4c9ae7c9696044eadb`). GitHub confirmed successful deployment and the expected site URL; the live github.io domain remains untested from this restricted workspace.

The terrain visibility revision `5fea8a9` uses a 12× default, a 24× slider limit, camera-relative side lighting, and clearer charcoal shading. Its local validation passed 16 geometry/data tests and 41 browser checks; the bundled prototype measurements and screenshots use the new default.

Terrain visibility deployment completed successfully: https://github.com/TrentConley/globe/actions/runs/37152397728. The published HTML matched the validated build byte-for-byte, SHA-256 `181e359f9f54de38e70f504dfe6b32efe21d1cf04dc76bac5286499eb61163f1`.


The physical-build design release adds a 25× default (40× adjustable limit), the detailed build-guide web page, an 18-page PDF, hardware references, seven small optical test prints, BOM/test-log CSVs, a reference matrix pattern and a bench utility. The kit preserves project source for maintenance. Validation for the release: 16 geometry/data tests, 41 simulator browser checks, 26 guide/link/layout checks, and independent geometry inspection of the nine supplied STL files. No hardware execution is implied.

The physical-build release was published at commit ca9a9cc. Its full Pages workflow completed with Status Success (build 43 s, deploy 13 s): https://github.com/TrentConley/globe/actions/runs/37156657901. The public raw simulator, HTML guide, PDF and source-reference page matched the locally checked files byte-for-byte. Direct live-domain browser testing remains unavailable in this workspace; desktop/phone browser validation used the same local build.
